shipApp.controller('pdetailsController', function ($scope) {
	// project details
	$scope.ShowId = function(event)
	{
	   alert(event);
	};
	
});