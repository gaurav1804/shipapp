shipApp.service('projectService', function () {
});
